import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cv-infor',
  templateUrl: './cv-infor.component.html',
  styleUrls: ['./cv-infor.component.scss']
})
export class CvInforComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
