import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-managed-staff',
  templateUrl: './managed-staff.component.html',
  styleUrls: ['./managed-staff.component.scss']
})
export class ManagedStaffComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
